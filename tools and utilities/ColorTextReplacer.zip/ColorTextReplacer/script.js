function replaceText(event) {
  // prevent form submission and page refresh
  event.preventDefault();

  // get input text
  const inputText = document.getElementById("input-text").value;

  // get target text
  const targetText = document.getElementById("target-text").value;

  // get replace text
  const replaceText = document.getElementById("replace-text").value;

  // replace target text with replace text
  const outputText = inputText.replaceAll(targetText, replaceText);

  // display output text
  document.getElementById("output-text").value = outputText;
}

function saveFile() {
  // get output text
  const outputText = document.getElementById("output-text").value;

  // create a new blob object
  const blob = new Blob([outputText], { type: "text/plain" });

  // create a new URL for the blob object
  const url = URL.createObjectURL(blob);

  // create a new anchor element
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "modified.tpl";

  // click the anchor element to start the download
  anchor.click();

  // release the URL object
  URL.revokeObjectURL(url);
}

function loadFile() {
  // get selected file
  const file = document.getElementById("file-input").files[0];

  // create a new file reader
  const reader = new FileReader();

  // define what happens when the file is loaded
  reader.onload = function(event) {
    // set input text to file contents
    document.getElementById("input-text").value = event.target.result;
  }

  // read the selected file as text
  reader.readAsText(file);
}
